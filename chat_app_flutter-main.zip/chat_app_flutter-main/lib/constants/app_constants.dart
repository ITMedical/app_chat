class AppConstants {
  static const appTitle = "Smart Talk";
  static const loginTitle = "Login Page";
  static const homeTitle = "Home Page";
  static const profileTitle = "Profile Page";
  static const fullPhotoTitle = "Image Full Size";
}
